README for textFiles
