README for general images
